<header>
   <div class="header-area">
      <div id="sticky-header" class="main-header-area">
         <div class="container-fluid p-0">
            <div class="row align-items-center no-gutters">
               <div class="col">
                  <div class="logo-img">
                     <a  href="<?php echo e(route('homepage')); ?>">                    
                     <img src="<?php echo e(get_company_logo()); ?>" alt="<?php echo e(settings('company_name')); ?>" >
                     </a>
                  </div>
               </div>
               <div class="col-md-auto">
                  <div class="main-menu  d-none d-lg-block">
                     <nav>
                        <ul id="navigation">
                           <li><a class="<?php echo e(is_active_menu('homepage')); ?>" href="<?php echo e(route('homepage')); ?>">Home</a></li>
                           <li><a  class="<?php echo e(is_active_menu('pricing')); ?>" href="<?php echo e(route('pricing')); ?>">Pricing</a></li>
                           <li><a class="<?php echo e(is_active_menu('how_it_works')); ?>" href="<?php echo e(route('how_it_works')); ?>">How it works</a></li>
                           <li><a class="<?php echo e(is_active_menu('faq')); ?>" href="<?php echo e(route('faq')); ?>">FAQ</a></li>
                           <li><a class="<?php echo e(is_active_menu('contact')); ?>" href="<?php echo e(route('contact')); ?>">Contact</a></li>
                           <?php if(!settings('disable_writer_application') && settings('show_writer_application_link_website_top_menu')): ?>
                           <li><a href="<?php echo e(route('writer_application_page')); ?>"><?php echo e(settings('writer_application_page_link_title')); ?></a></li>
                           <?php endif; ?>
                           <li><a class="<?php echo e(is_active_menu('order_page')); ?>" href="<?php echo e(route('order_page')); ?>">Order Now</a></li>
                        </ul>
                     </nav>
                  </div>
               </div>
               <div class="col d-none d-lg-block">
                  <div class="log_chat_area d-flex align-items-center">
                     <?php if(auth()->guard()->check()): ?>
                     <a href="<?php echo e(route(get_default_route_by_user(auth()->user()))); ?>" class="login">
                     <i class="flaticon-user"></i>
                     <span>My Account</span>
                     </a>
                     <?php endif; ?>
                     <?php if(auth()->guard()->guest()): ?>
                     <a href="<?php echo e(route('login')); ?>" class="login">
                     <i class="flaticon-user"></i>
                     <span>log in</span>
                     </a>
                     <?php endif; ?>
                     <div class="live_chat_btn">
                        <a class="boxed_btn_orange" href="#">
                        <i class="fa fa-phone"></i>
                        <span><?php echo Purifier::clean(settings('company_phone')); ?></span>
                        </a>
                     </div>
                  </div>
               </div>
               <div class="col-12">
                  <div class="mobile_menu d-block d-lg-none"></div>
               </div>
            </div>
         </div>
      </div>
   </div>
</header><?php /**PATH D:\laragon\www\essay\resources\views/website/layouts/header.blade.php ENDPATH**/ ?>