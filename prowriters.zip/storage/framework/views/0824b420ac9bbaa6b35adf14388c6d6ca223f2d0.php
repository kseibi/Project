<!-- footer -->
<footer class="footer footer_bg_1">
   <div class="footer_top">
      <div class="container">
         <div class="row">
            <div class="col-xl-4 col-md-6 col-lg-4">
               <div class="footer_widget">
                  <div class="footer_logo">
                     <a href="#">
                     <img src="<?php echo e(get_company_logo()); ?>" alt="<?php echo e(settings('company_name')); ?>">
                     </a>
                  </div>
                  <p><?php echo nl2br(Purifier::clean(settings('company_about'))); ?></p>
                  <div class="socail_links">
                     <ul>
                        <?php if($link = settings('facebook')): ?>
                        <li>
                           <a href="<?php echo e($link); ?>" target="_blank">
                           <i class="fab fa-facebook-square"></i>
                           </a>
                        </li>
                        <?php endif; ?>
                        <?php if($link = settings('twitter')): ?>
                        <li>
                           <a href="<?php echo e($link); ?>" target="_blank">
                           <i class="fab fa-twitter-square"></i>
                           </a>
                        </li>
                        <?php endif; ?>
                        <?php if($link = settings('instagram')): ?>
                        <li>
                           <a href="<?php echo e($link); ?>" target="_blank">
                           <i class="fab fa-instagram"></i>
                           </a>
                        </li>
                        <?php endif; ?>
                        <?php if($link = settings('linkedin')): ?>
                        <li>
                           <a href="<?php echo e($link); ?>" target="_blank">
                           <i class="fab fa-linkedin"></i>
                           </a>
                        </li>
                        <?php endif; ?>
                     </ul>
                  </div>
               </div>
            </div>
            <div class="col-xl-2 offset-xl-1 col-md-6 col-lg-3">
               <div class="footer_widget">
                  <h3 class="footer_title">
                     Main Menu
                  </h3>
                  <ul>
                     <li><a href="<?php echo e(route('homepage')); ?>">Home</a></li>
                     <li><a href="<?php echo e(route('pricing')); ?>">Pricing</a></li>
                     <li><a href="<?php echo e(route('how_it_works')); ?>">How it works</a></li>
                     <li><a href="<?php echo e(route('faq')); ?>">FAQ</a></li>
                     <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                     <?php if(!settings('disable_writer_application')): ?>
                     <li><a href="<?php echo e(route('writer_application_page')); ?>"><?php echo e(settings('writer_application_page_link_title')); ?></a></li>
                     <?php endif; ?>
                  </ul>
               </div>
            </div>
            <div class="col-xl-3 col-md-6 col-lg-2">
               <div class="footer_widget">
                  <h3 class="footer_title">
                     Legal Info
                  </h3>
                  <ul>
                     <li><a href="<?php echo e(route('money_back_guarantee')); ?>">Money Back Guarantee</a></li>
                     <li><a href="<?php echo e(route('privacy_policy')); ?>">Privacy Policy</a></li>
                     <li><a href="<?php echo e(route('revision_policy')); ?>">Revision Policy</a></li>
                     <li><a href="<?php echo e(route('disclaimer')); ?>">Disclaimer</a></li>
                     <li><a href="<?php echo e(route('terms_and_conditions')); ?>">Terms & Condition</a></li>
                  </ul>
               </div>
            </div>
            <div class="col-xl-2 col-md-6 col-lg-3">
               <div class="footer_widget">
                  <h3 class="footer_title">
                     We accept
                  </h3>
                  <p class="font-24">
                     <i class="fab fa-cc-visa"></i>  
                     <i class="fab fa-cc-mastercard"></i>  
                     <i class="fab fa-cc-discover"></i> 
                     <?php if(settings('enable_paypal')): ?>
                     <i class="fab fa-cc-paypal"></i>
                     <?php endif; ?>                                  
                  </p>
               </div>
            </div>
         </div>
      </div>
   </div>
   <div class="copy-right_text">
      <div class="container">
         <div class="footer_border"></div>
         <div class="row">
            <div class="col-xl-12">
               <p class="copy_right text-center">
                  <?php echo e(date("Y")); ?>  <?php echo Purifier::clean(settings('footer_text')); ?>

               </p>
            </div>
         </div>
      </div>
   </div>
</footer>
<!-- footer --><?php /**PATH D:\laragon\www\essay\prowriters\resources\views/website/layouts/footer.blade.php ENDPATH**/ ?>