
<?php $__env->startSection('title', $bill->number); ?>
<?php $__env->startSection('content'); ?>
<div class="container page-container">
   <div class="row">
      <div class="col-md-12">
         <h4><?php echo e($bill->number); ?></h4>
         <hr>
      </div>
      <div class="col-md-9">
         <?php echo $__env->make('bill.partials.details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
      <div class="col-md-3">
         <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?> 
            <?php if($bill->paid): ?>
            <form action="<?php echo e(route('bill_mark_as_unpaid', $bill->id)); ?>" method="POST" autocomplete="off">
               <?php echo e(csrf_field()); ?>  
               <button type="submit" class="btn btn-light btn-lg btn-block">
               <i class="far fa-check-circle"></i> Mark as unpaid</button>
            </form>
            <div class="text-center form-text text-muted">
               Payment Date: <br>
               <?php echo e($bill->paid->format('d-M-Y')); ?>

            </div>
            <?php else: ?>
            <form action="<?php echo e(route('bill_mark_as_paid', $bill->id)); ?>" method="POST" autocomplete="off">
               <?php echo e(csrf_field()); ?>  
               <button type="submit" class="btn btn-success btn-lg btn-block">
               <i class="far fa-check-circle"></i> Mark as paid</button>
            </form>
            <?php endif; ?>
         <?php endif; ?>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\essay\resources\views/bill/show.blade.php ENDPATH**/ ?>