<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
<?php if(trim($slot) === 'Laravel'): ?>

<?php echo e(get_company_name()); ?>

<?php else: ?>
<?php echo e($slot); ?>

<?php endif; ?>
</a>
</td>
</tr>
<?php /**PATH D:\laragon\www\essay\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>