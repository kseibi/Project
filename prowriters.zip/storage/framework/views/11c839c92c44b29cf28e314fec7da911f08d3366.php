
<?php if($content->count() > 0): ?>
<?php $__env->startSection('title', Purifier::clean($content->title)); ?>
<?php $__env->startSection('content'); ?>
<div class="bradcam_area breadcam_bg overlay2">
   <h3><?php echo e(Purifier::clean($content->title)); ?></h3>
</div>
<div class="about_area">
   <div class="container">
      <div class="row">
         <div class="offset-lg-2 col-lg-8">                    
            <?php echo Purifier::clean($content->description); ?>
         </div>
      </div>
   </div>
</div>

<?php $__env->stopSection(); ?>

<?php endif; ?>
<?php echo $__env->make('website.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\essay\resources\views/website/content.blade.php ENDPATH**/ ?>