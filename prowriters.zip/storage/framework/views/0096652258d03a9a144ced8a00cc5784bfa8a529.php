<?php if($order->order_status_id == ORDER_STATUS_IN_PROGRESS): ?>
 <submit-work 
:submit_work_url="'<?php echo e(route('submit_work', $order->id)); ?>'"
:upload_attachment_url="'<?php echo e(route('order_upload_attachment')); ?>'"></submit-work>

<?php elseif($order->order_status_id == in_array($order->order_status_id, [ORDER_STATUS_NEW, ORDER_STATUS_REQUESTED_FOR_REVISION])): ?>

	<?php if($order->order_status_id == ORDER_STATUS_REQUESTED_FOR_REVISION): ?>
		<?php $feedback = $order->latest_submitted_work(); ?>
		<div><small class="form-text text-muted">Posted at : <?php echo e($feedback->updated_at); ?> </small></div>
		<label>Message from customer:</label>			
		<p><?php echo e($order->latest_submitted_work()->customer_message); ?></p>
	<?php endif; ?>

	<form action="<?php echo e(route('start_working', $order->id)); ?>" method="POST" autocomplete="off">
		<?php echo e(csrf_field()); ?>

		<input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">
		<button class="btn btn-success btn-lg btn-block" type="submit" name="submit"><i class="fas fa-rocket"></i> Start Working</button>
		
	</form>
<?php endif; ?>
<?php /**PATH D:\laragon\www\essay\resources\views/order/partials/submit_work.blade.php ENDPATH**/ ?>