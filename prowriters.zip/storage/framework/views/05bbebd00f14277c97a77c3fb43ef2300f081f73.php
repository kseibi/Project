<table id="table" class="w-100">
    <thead>
        <tr>
            <th scope="col"></th>
        </tr>
    </thead>
</table>
<?php $__env->startSection('innerJs'); ?>
<script>
    $(function () {

        var oTable = $('#table').DataTable({
            "bLengthChange": false,
            searching: false,
            processing: true,
            serverSide: true,
            sorting: false,
            ordering: false,
            "ajax": {
                "url": "<?php echo route('orders_datatable', ['customer_id' => $user->id]); ?>",
                "type": "POST",
                'headers': {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                }

            },
            columns: [{
                    data: 'customer_html',
                    name: 'customer_html'
                }

            ]
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php /**PATH D:\laragon\www\essay\resources\views/user/partials/orders.blade.php ENDPATH**/ ?>