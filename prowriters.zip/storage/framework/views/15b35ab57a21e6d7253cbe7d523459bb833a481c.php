<?php if(count($data['statistics']) > 0): ?>
	<?php $__currentLoopData = $data['statistics']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $segment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="row mb-4">
		<?php $__currentLoopData = $segment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="col-md-2 col-sm-6">         	
         	<div class="shadow bg-white rounded text-center p-1">
            <div class="mt-2"><?php echo e($row['value']); ?></div>
            <span style="font-size: 12px;" class="text-<?php echo e(str_replace('badge-','',$row['badge'])); ?>"><?php echo e($row['name']); ?></span>
        	</div>        	
         </div>         
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\essay\resources\views/order/partials/statistics.blade.php ENDPATH**/ ?>